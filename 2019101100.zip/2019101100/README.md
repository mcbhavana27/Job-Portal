# MERN Stack Website

* 2019101100

## Running the code

* Run Mongo daemon:
```
sudo mongod
```
Mongo will be running on port 4000.


* Run Express Backend:
```
cd backend/
npm install
npm start
```

* Run React Frontend:
```
cd frontend
npm install/
npm start
```


